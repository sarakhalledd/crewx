const xicon = document.querySelector('.xicon');
          
// Add an event listener to handle click events
xicon.addEventListener('click', function() {
  // Redirect to home.html
  window.location.href = 'Home.html';
});

